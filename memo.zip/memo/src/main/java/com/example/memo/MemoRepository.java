package com.example.memo;

import java.util.List;

public interface MemoRepository {
	
	boolean insert(Memo memo);
	List<Memo> findAll();
	
	Memo findById(Long id);
	boolean update(Memo memo);
	
	boolean deleteById(Long id);
}
