package com.example.memo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MemoService {
	
	@Autowired
	private MemoRepository memoRepository;
	
	public String saveMemo(Memo memo) {
		boolean result = memoRepository.insert(memo);
		
		String message = "저장 되지 않았습니다.";
		
		if(result) {
			message = "저장되었습니다.";
		}
		
		return message; 
		
	}
	
	public List<Memo> getMemos(){
		return memoRepository.findAll();
	}
	
	public Memo getMemoById(Long id) {
		return memoRepository.findById(id);
	}
	
	public String updateMemo(Memo memo) {
		boolean result = memoRepository.update(memo);
		
		String message = "수정 되지 않았습니다.";
		
		if(result) {
			message = "수정 되었습니다.";
		}
		
		return message; 		
	}
	
	public String deleteMemo(Long id) {
		boolean result = memoRepository.deleteById(id);
		
		String message = "삭제 되지 않았습니다.";
		
		if(result) {
			message = "삭제 되었습니다.";
		}
		
		return message; 		
	}
}











