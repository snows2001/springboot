package com.example.memo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MemoController {
	
	@Autowired
	private MemoService memoService;
	
	@GetMapping("/save")
	public String getForm() {		
		return "memoForm";
	}
	
	@PostMapping("/save")
	public String add(@ModelAttribute Memo memo, Model model) {
		//System.out.println(memo);
		String result = memoService.saveMemo(memo);
		
		model.addAttribute("message", result);
		
		return "redirect:/list";
	}
	
	@GetMapping("/list")
	public String list(Model model) {
		
		List<Memo> memos = memoService.getMemos();
		model.addAttribute("memos", memos);
		
		return "list";
	}
	
	@GetMapping("/detail/{id}")
	public String detail(@PathVariable("id") Long id, Model model) {
		
		model.addAttribute("memo", memoService.getMemoById(id));
		return "detail";
	}
	
	@PostMapping("/update")
	public String updateMemo(@ModelAttribute Memo memo, Model model) {
		String result = memoService.updateMemo(memo);
		model.addAttribute("message", result);
		
		return "result";
	}
	
	@GetMapping("/delete")
	public String deleteMemo(@RequestParam("id") Long id, Model model) {
		String result = memoService.deleteMemo(id);
		model.addAttribute("message", result);
		
		return "result";
	}
}








